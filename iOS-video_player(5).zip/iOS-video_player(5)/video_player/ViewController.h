//
//  ViewController.h
//  video_player
//
//  Created by apple on 2017/7/11.
//  Copyright © 2017年 xiaokai.zhan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

